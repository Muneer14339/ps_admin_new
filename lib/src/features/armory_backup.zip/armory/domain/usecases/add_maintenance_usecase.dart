import 'package:dartz/dartz.dart';
import '../../../../core/services/error/failures.dart';
import '../../../../core/services/usecases/usecase.dart';
import '../repositories/armory_repository.dart';

// lib/user_dashboard/domain/usecases/add_maintenance_usecase.dart
class AddMaintenanceUseCase implements UseCase<void, AddMaintenanceParams> {
  final ArmoryRepository repository;

  AddMaintenanceUseCase(this.repository);

  @override
  Future<Either<Failure, void>> call(AddMaintenanceParams params) async {
    return await repository.addMaintenance(params.userId, params.maintenance);
  }
}