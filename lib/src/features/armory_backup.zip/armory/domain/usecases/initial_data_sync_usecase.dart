import 'package:dartz/dartz.dart';
import 'package:pa_sreens/src/core/services/logger.dart';

import '../../../../core/services/error/failures.dart';
import '../../../../core/services/usecases/usecase.dart';

import '../../data/datasources/armory_local_dataresouces.dart';
import '../../data/datasources/armory_remote_datasource.dart';
import '../../data/models/armory_ammunition_model.dart';
import '../../data/models/armory_firearm_model.dart';

class InitialDataSyncUseCase implements UseCase<void, UserIdParams> {
  final ArmoryRemoteDataSource remoteDataSource;
  final ArmoryLocalDataSource localDataSource;

  InitialDataSyncUseCase({
    required this.remoteDataSource,
    required this.localDataSource,
  });

  @override
  Future<Either<Failure, void>> call(UserIdParams params) async {
    try {
      final isEmpty = await localDataSource.isDatabaseEmpty();

      if (!isEmpty) {
        log.i('📦 Local database already has data, skipping sync');
        return const Right(null);
      }

      log.i('🔄 Starting initial data sync for user: ${params.userId}');

      // System Firearms
      log.i('📥 Fetching system firearms...');
      final systemFirearmsData = await remoteDataSource.getFirearmsRawData();
      final systemFirearms = systemFirearmsData
          .map<ArmoryFirearmModel>((e) => ArmoryFirearmModel.fromMap(e, e['id']))
          .toList();
      await localDataSource.saveSystemFirearms(systemFirearms);
      log.i('✅ Saved ${systemFirearms.length} system firearms');

      // System Ammunition
      log.i('📥 Fetching system ammunition...');
      final systemAmmoData = await remoteDataSource.getAmmunitionRawData();
      final systemAmmo = systemAmmoData
          .map<ArmoryAmmunitionModel>((e) => ArmoryAmmunitionModel.fromMap(e, e['id']))
          .toList();
      await localDataSource.saveSystemAmmunition(systemAmmo);
      log.i('✅ Saved ${systemAmmo.length} system ammunition');

      // User Firearms
      log.i('📥 Fetching user firearms...');
      final userFirearms = await remoteDataSource.getFirearms(params.userId);
      await localDataSource.saveUserFirearms(params.userId, userFirearms);
      log.i('✅ Saved ${userFirearms.length} user firearms');

      // User Ammunition
      log.i('📥 Fetching user ammunition...');
      final userAmmunition = await remoteDataSource.getAmmunition(params.userId);
      await localDataSource.saveUserAmmunition(params.userId, userAmmunition);
      log.i('✅ Saved ${userAmmunition.length} user ammunition');

      // User Gear
      log.i('📥 Fetching user gear...');
      final userGear = await remoteDataSource.getGear(params.userId);
      await localDataSource.saveUserGear(params.userId, userGear);
      log.i('✅ Saved ${userGear.length} user gear items');

      // User Tools
      log.i('📥 Fetching user tools...');
      final userTools = await remoteDataSource.getTools(params.userId);
      await localDataSource.saveUserTools(params.userId, userTools);
      log.i('✅ Saved ${userTools.length} user tools');

      // User Loadouts
      log.i('📥 Fetching user loadouts...');
      final userLoadouts = await remoteDataSource.getLoadouts(params.userId);
      await localDataSource.saveUserLoadouts(params.userId, userLoadouts);
      log.i('✅ Saved ${userLoadouts.length} user loadouts');

      // User Maintenance
      log.i('📥 Fetching user maintenance records...');
      final userMaintenance = await remoteDataSource.getMaintenance(params.userId);
      await localDataSource.saveUserMaintenance(params.userId, userMaintenance);
      log.i('✅ Saved ${userMaintenance.length} maintenance records');

      log.i('🎉 Initial data sync completed successfully');
      return const Right(null);
    } catch (e, stackTrace) {
      log.e('❌ Failed to sync initial data: $e\n$stackTrace');
      return Left(FileFailure('Failed to sync data: $e'));
    }
  }
}