import 'dart:developer';


import '../../../../core/services/sqflite_service/database_helper.dart';
import '../models/armory_ammunition_model.dart';
import '../models/armory_firearm_model.dart';
import '../models/armory_gear_model.dart';
import '../models/armory_loadout_model.dart';
import '../models/armory_maintenance_model.dart';
import '../models/armory_tool_model.dart';
import 'package:sqflite/sqflite.dart';

import 'armory_local_dataresouces.dart';

class ArmoryLocalDataSourceImpl implements ArmoryLocalDataSource {
  final DatabaseHelper _dbHelper;

  ArmoryLocalDataSourceImpl({required DatabaseHelper dbHelper}) : _dbHelper = dbHelper;

  Future<Database> get _db async => await _dbHelper.database;

  @override
  Future<List<ArmoryFirearmModel>> getFirearms(String userId) async {
    final db = await _db;
    final maps = await db.query('firearms', where: 'userId = ?', whereArgs: [userId]);
    return maps.map((map) => ArmoryFirearmModel.fromMap(map, map['id'] as String)).toList();
  }

  @override
  Future<void> addFirearm(String userId, ArmoryFirearmModel firearm) async {
    final db = await _db;
    final map = firearm.toMap();
    map['userId'] = userId;
    map['id'] = firearm.id;
    await db.insert('firearms', map, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  @override
  Future<void> updateFirearm(String userId, ArmoryFirearmModel firearm) async {
    final db = await _db;
    await db.update('firearms', firearm.toMap(), where: 'id = ? AND userId = ?', whereArgs: [firearm.id, userId]);
  }

  @override
  Future<void> deleteFirearm(String userId, String firearmId) async {
    final db = await _db;
    await db.delete('firearms', where: 'id = ? AND userId = ?', whereArgs: [firearmId, userId]);
  }

  @override
  Future<List<ArmoryAmmunitionModel>> getAmmunition(String userId) async {
    final db = await _db;
    final maps = await db.query('ammunition', where: 'userId = ?', whereArgs: [userId]);
    return maps.map((map) => ArmoryAmmunitionModel.fromMap(map, map['id'] as String)).toList();
  }

  @override
  Future<void> addAmmunition(String userId, ArmoryAmmunitionModel ammo) async {
    final db = await _db;
    final map = ammo.toMap();
    map['userId'] = userId;
    map['id'] = ammo.id;
    await db.insert('ammunition', map, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  @override
  Future<void> updateAmmunition(String userId, ArmoryAmmunitionModel ammo) async {
    final db = await _db;
    await db.update('ammunition', ammo.toMap(), where: 'id = ? AND userId = ?', whereArgs: [ammo.id, userId]);
  }

  @override
  Future<void> deleteAmmunition(String userId, String ammoId) async {
    final db = await _db;
    await db.delete('ammunition', where: 'id = ? AND userId = ?', whereArgs: [ammoId, userId]);
  }

  @override
  Future<List<ArmoryGearModel>> getGear(String userId) async {
    final db = await _db;
    final maps = await db.query('gear', where: 'userId = ?', whereArgs: [userId]);
    return maps.map((map) => ArmoryGearModel.fromMap(map, map['id'] as String)).toList();
  }

  @override
  Future<void> addGear(String userId, ArmoryGearModel gear) async {
    final db = await _db;
    final map = gear.toMap();
    map['userId'] = userId;
    map['id'] = gear.id;
    await db.insert('gear', map, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  @override
  Future<void> updateGear(String userId, ArmoryGearModel gear) async {
    final db = await _db;
    await db.update('gear', gear.toMap(), where: 'id = ? AND userId = ?', whereArgs: [gear.id, userId]);
  }

  @override
  Future<void> deleteGear(String userId, String gearId) async {
    final db = await _db;
    await db.delete('gear', where: 'id = ? AND userId = ?', whereArgs: [gearId, userId]);
  }

  @override
  Future<List<ArmoryToolModel>> getTools(String userId) async {
    final db = await _db;
    final maps = await db.query('tools', where: 'userId = ?', whereArgs: [userId]);
    return maps.map((map) => ArmoryToolModel.fromMap(map, map['id'] as String)).toList();
  }

  @override
  Future<void> addTool(String userId, ArmoryToolModel tool) async {
    final db = await _db;
    final map = tool.toMap();
    map['userId'] = userId;
    map['id'] = tool.id;
    await db.insert('tools', map, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  @override
  Future<void> updateTool(String userId, ArmoryToolModel tool) async {
    final db = await _db;
    await db.update('tools', tool.toMap(), where: 'id = ? AND userId = ?', whereArgs: [tool.id, userId]);
  }

  @override
  Future<void> deleteTool(String userId, String toolId) async {
    final db = await _db;
    await db.delete('tools', where: 'id = ? AND userId = ?', whereArgs: [toolId, userId]);
  }

  @override
  Future<List<ArmoryLoadoutModel>> getLoadouts(String userId) async {
    final db = await _db;
    final maps = await db.query('loadouts', where: 'userId = ?', whereArgs: [userId]);
    return maps.map((map) => ArmoryLoadoutModel.fromMap(map, map['id'] as String)).toList();
  }

  @override
  Future<void> addLoadout(String userId, ArmoryLoadoutModel loadout) async {
    final db = await _db;
    final map = loadout.toMap();
    map['userId'] = userId;
    map['id'] = loadout.id;
    await db.insert('loadouts', map, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  @override
  Future<void> updateLoadout(String userId, ArmoryLoadoutModel loadout) async {
    final db = await _db;
    await db.update('loadouts', loadout.toMap(), where: 'id = ? AND userId = ?', whereArgs: [loadout.id, userId]);
  }

  @override
  Future<void> deleteLoadout(String userId, String loadoutId) async {
    final db = await _db;
    await db.delete('loadouts', where: 'id = ? AND userId = ?', whereArgs: [loadoutId, userId]);
  }

  @override
  Future<List<ArmoryMaintenanceModel>> getMaintenance(String userId) async {
    final db = await _db;
    final maps = await db.query('maintenance', where: 'userId = ?', whereArgs: [userId]);
    return maps.map((map) => ArmoryMaintenanceModel.fromMap(map, map['id'] as String)).toList();
  }

  @override
  Future<void> addMaintenance(String userId, ArmoryMaintenanceModel maintenance) async {
    final db = await _db;
    final map = maintenance.toMap();
    map['userId'] = userId;
    map['id'] = maintenance.id;
    await db.insert('maintenance', map, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  @override
  Future<void> deleteMaintenance(String userId, String maintenanceId) async {
    final db = await _db;
    await db.delete('maintenance', where: 'id = ? AND userId = ?', whereArgs: [maintenanceId, userId]);
  }

  @override
  Future<List<Map<String, dynamic>>> getFirearmsRawData() async {
    final db = await _db;
    return await db.query('systemFirearms');
  }

  @override
  Future<List<Map<String, dynamic>>> getAmmunitionRawData() async {
    final db = await _db;
    return await db.query('systemAmmunition');
  }

  @override
  Future<List<Map<String, dynamic>>> getUserFirearmsRawData(String userId) async {
    final db = await _db;
    return await db.query('firearms', where: 'userId = ?', whereArgs: [userId]);
  }

  @override
  Future<List<Map<String, dynamic>>> getUserAmmunitionRawData(String userId) async {
    final db = await _db;
    return await db.query('ammunition', where: 'userId = ?', whereArgs: [userId]);
  }

  @override
  Future<void> saveSystemFirearms(List<ArmoryFirearmModel> firearms) async {
    final db = await _db;
    final batch = db.batch();
    batch.delete('systemFirearms');
    for (final firearm in firearms) {
      final map = firearm.toMap();
      map['id'] = firearm.id;
      batch.insert('systemFirearms', map, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    await batch.commit(noResult: true);
  }

  @override
  Future<void> saveSystemAmmunition(List<ArmoryAmmunitionModel> ammunition) async {
    final db = await _db;
    final batch = db.batch();
    batch.delete('systemAmmunition');
    for (final ammo in ammunition) {
      final map = ammo.toMap();
      map['id'] = ammo.id;
      batch.insert('systemAmmunition', map, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    await batch.commit(noResult: true);
  }

  @override
  Future<void> saveUserFirearms(String userId, List<ArmoryFirearmModel> firearms) async {
    final db = await _db;
    final batch = db.batch();
    for (final firearm in firearms) {
      final map = firearm.toMap();
      map['userId'] = userId;
      map['id'] = firearm.id;
      batch.insert('firearms', map, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    await batch.commit(noResult: true);
  }

  @override
  Future<void> saveUserAmmunition(String userId, List<ArmoryAmmunitionModel> ammunition) async {
    final db = await _db;
    final batch = db.batch();
    for (final ammo in ammunition) {
      final map = ammo.toMap();
      map['userId'] = userId;
      map['id'] = ammo.id;
      batch.insert('ammunition', map, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    await batch.commit(noResult: true);
  }

  @override
  Future<void> saveUserGear(String userId, List<ArmoryGearModel> gear) async {
    final db = await _db;
    final batch = db.batch();
    for (final item in gear) {
      final map = item.toMap();
      map['userId'] = userId;
      map['id'] = item.id;
      batch.insert('gear', map, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    await batch.commit(noResult: true);
  }

  @override
  Future<void> saveUserTools(String userId, List<ArmoryToolModel> tools) async {
    final db = await _db;
    final batch = db.batch();
    for (final tool in tools) {
      final map = tool.toMap();
      map['userId'] = userId;
      map['id'] = tool.id;
      batch.insert('tools', map, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    await batch.commit(noResult: true);
  }

  @override
  Future<void> saveUserLoadouts(String userId, List<ArmoryLoadoutModel> loadouts) async {
    final db = await _db;
    final batch = db.batch();
    for (final loadout in loadouts) {
      final map = loadout.toMap();
      map['userId'] = userId;
      map['id'] = loadout.id;
      batch.insert('loadouts', map, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    await batch.commit(noResult: true);
  }

  @override
  Future<void> saveUserMaintenance(String userId, List<ArmoryMaintenanceModel> maintenance) async {
    final db = await _db;
    final batch = db.batch();
    for (final item in maintenance) {
      final map = item.toMap();
      map['userId'] = userId;
      map['id'] = item.id;
      batch.insert('maintenance', map, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    await batch.commit(noResult: true);
  }

  @override
  Future<bool> isDatabaseEmpty() async {
    try {
      final db = await _db;
      final userFirearmsCount = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM firearms')) ?? 0;
      return userFirearmsCount == 0;
    } catch (e) {
      return true;
    }
  }

  @override
  Future<void> clearAllData() async {
    final db = await _db;
    final batch = db.batch();
    batch.delete('firearms');
    batch.delete('ammunition');
    batch.delete('gear');
    batch.delete('tools');
    batch.delete('loadouts');
    batch.delete('maintenance');
    batch.delete('systemFirearms');
    batch.delete('systemAmmunition');
    await batch.commit(noResult: true);
  }
}