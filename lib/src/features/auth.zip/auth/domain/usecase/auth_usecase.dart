import 'package:dartz/dartz.dart';
import 'package:injectable/injectable.dart';
import 'package:pa_sreens/src/features/auth/data/model/login_model.dart';
import 'package:pa_sreens/src/features/auth/data/model/signup_model.dart';
import 'package:pa_sreens/src/features/auth/domain/repository/auth_repository.dart';

import '../../data/model/user_model.dart';

@injectable
class SignupUsecase {
  SignupUsecase(this._signupRepository);

  final SignupRepository _signupRepository;

  Future<Either<Map<String, dynamic>, String>> createSignup(
      SignupModel signupModel) async {
    return await _signupRepository.signupCreate(signupModel);
  }

  //------------------------- verifyEmail

  Future<Either<Map<String, dynamic>, String>> verifyEmail(String otp) async {
    return await _signupRepository.verifyEmail(otp);
  }

  //------------------------- login

  Future<Either<UserModel, String>> login(LoginModel loginModel) async {
    return await _signupRepository.login(loginModel);
  }

  //------------------------- resetPassword

  Future<Either<Map<String, dynamic>, String>> passwordResetToken(
      String email) async {
    return await _signupRepository.passwordResetToken(email);
  }

  //------------------------- passwordResetTokenValidate

  Future<Either<Map<String, dynamic>, String>> passwordResetTokenValidate(
      String email) async {
    return await _signupRepository.passwordResetTokenValidate(email);
  }

  //------------------------- passwordResetConfirm

  Future<Either<Map<String, dynamic>, String>> passwordResetConfirm(
      String pass, String token) async {
    return await _signupRepository.passwordResetConfirm(pass, token);
  }
}
