import 'package:dartz/dartz.dart';
import 'package:pa_sreens/src/features/auth/data/model/login_model.dart';
import 'package:pa_sreens/src/features/auth/data/model/signup_model.dart';

import '../../data/model/user_model.dart';

abstract class SignupRepository {
  Future<Either<Map<String, dynamic>, String>> signupCreate(
      SignupModel signupModel);

  Future<Either<Map<String, dynamic>, String>> verifyEmail(String otp);

  Future<Either<UserModel, String>> login(LoginModel loginModel);

  Future<Either<Map<String, dynamic>, String>> passwordResetToken(String email);

  Future<Either<Map<String, dynamic>, String>> passwordResetTokenValidate(
      String token);

  Future<Either<Map<String, dynamic>, String>> passwordResetConfirm(
      String pass, String token);
}
