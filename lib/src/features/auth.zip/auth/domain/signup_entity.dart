// ignore_for_file: public_member_api_docs, sort_constructors_first
class SignupEntity {
  String fullName;
  String email;
  String password;
  String location;
  bool agreeToRecieve;
  bool agreeToTerms;
  bool obscurePassword;
  SignupEntity({
    required this.fullName,
    required this.email,
    required this.password,
    required this.location,
    required this.agreeToRecieve,
    required this.agreeToTerms,
    required this.obscurePassword
  });
  SignupEntity copyWith({
    String? fullName,
    String? email,
    String? password,
    String? location,
    bool? agreeToRecieve,
    bool? agreeToTerms,
    bool? obscurePassword,
    bool? obscureConfirmPassword,
  }) {
    return SignupEntity(
      fullName: fullName ?? this.fullName,
      email: email ?? this.email,
      password: password ?? this.password,
      location: location ?? this.location,
      agreeToRecieve: agreeToRecieve ?? this.agreeToRecieve,
      agreeToTerms: agreeToTerms ?? this.agreeToTerms,
      obscurePassword: obscurePassword ?? this.obscurePassword,
      // obscureConfirmPassword:
      //     obscureConfirmPassword ?? this.obscureConfirmPassword,
    );
  }
}
