import 'package:dio/dio.dart';
import 'package:injectable/injectable.dart';
import 'package:pa_sreens/src/core/services/network_service/dio_service.dart';
import 'package:pa_sreens/src/core/services/network_service/endpoints.dart';
import 'package:pa_sreens/src/features/auth/data/model/login_model.dart';
import 'package:pa_sreens/src/features/auth/data/model/signup_model.dart';

@injectable
class AuthService {
  final dioService = DioService();

  Future<Response?> signupCreate(SignupModel signupModel) async {
    Response? response = await dioService.dioPost(
        fullUrl: createSignup,
        obj: signupModel.toJson(),
        useToken: false,
        post: true);
    return response;
  }

  // -----------------   verifyEmail

  Future<Response?> verifyEmail(String otp) async {
    Response? response = await dioService.dioPost(
        fullUrl: verifyEmailUrl,
        obj: {'otp_token': otp},
        useToken: false,
        post: true);
    return response;
  }

  // -----------------   userLogin

  Future<Response?> login(LoginModel loginModel) async {
    Response? response = await dioService.dioPost(
        fullUrl: loginUrl,
        obj: loginModel.toJson(),
        useToken: false,
        post: true);
    return response;
  }

  // -----------------   passwordReset

  Future<Response?> passwordResetToken(String email) async {
    Response? response = await dioService.dioPost(
        fullUrl: passwordResetUrl,
        obj: {'email': email},
        useToken: false,
        post: true);
    return response;
  }

  // -----------------   passwordReset

  Future<Response?> passwordResetTokenValidate(String token) async {
    Response? response = await dioService.dioPost(
        fullUrl: passwordResetValidateUrl,
        obj: {'token': token},
        useToken: false,
        post: true);
    return response;
  }

  // -----------------   passwordResetConfirm

  Future<Response?> passwordResetConfirm(String pass, String token) async {
    Response? response = await dioService.dioPost(
        fullUrl: passwordResetConfirmUrl,
        obj: {'password': pass, 'token': token},
        useToken: false,
        post: true);
    return response;
  }
}
