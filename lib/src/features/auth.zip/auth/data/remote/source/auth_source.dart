import 'package:dio/dio.dart';
import 'package:pa_sreens/src/features/auth/data/model/signup_model.dart';

import '../../model/login_model.dart';

abstract class AuthSource {
  //-------------------- signupCreate

  Future<Response?> signupCreate(SignupModel signupModel);

  //-------------------- verifyEmail

  Future<Response?> verifyEmail(String otp);

  //-------------------- verifyEmail

  Future<Response?> login(LoginModel loginModel);

  //-------------------- passwordReset

  Future<Response?> passwordResetToken(String email);

  //-------------------- passwordReset

  Future<Response?> passwordResetTokenValidate(String token);

  //-------------------- passwordReset

  Future<Response?> passwordResetConfirm(String pass, String token);
}
