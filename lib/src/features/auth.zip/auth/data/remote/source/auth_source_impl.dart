import 'package:dio/dio.dart';
import 'package:injectable/injectable.dart';
import 'package:pa_sreens/src/features/auth/data/model/login_model.dart';
import 'package:pa_sreens/src/features/auth/data/model/signup_model.dart';
import 'package:pa_sreens/src/features/auth/data/remote/service/auth_service.dart';

import 'auth_source.dart';

@Injectable(as: AuthSource)
class AuthSourceImpl implements AuthSource {
  final AuthService _authService = AuthService();

  @override
  Future<Response?> signupCreate(SignupModel signupModel) {
    return _authService.signupCreate(signupModel);
  }

  @override
  Future<Response?> verifyEmail(String otp) {
    return _authService.verifyEmail(otp);
  }

  @override
  Future<Response?> login(LoginModel loginModel) {
    return _authService.login(loginModel);
  }

  @override
  Future<Response?> passwordResetToken(String email) {
    return _authService.passwordResetToken(email);
  }

  @override
  Future<Response?> passwordResetConfirm(String pass, String token) {
    return _authService.passwordResetConfirm(pass, token);
  }

  @override
  Future<Response?> passwordResetTokenValidate(String token) {
    return _authService.passwordResetTokenValidate(token);
  }
}
