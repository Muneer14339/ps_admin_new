import 'dart:developer';
import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:injectable/injectable.dart';
import 'package:pa_sreens/src/core/services/local_storage_service/local_storage_service.dart';
import 'package:pa_sreens/src/core/services/locator/locator.dart';
import 'package:pa_sreens/src/core/utils/error_handler.dart';
import 'package:pa_sreens/src/features/auth/data/model/login_model.dart';
import 'package:pa_sreens/src/features/auth/data/model/signup_model.dart';
import 'package:pa_sreens/src/features/auth/data/model/user_model.dart';
import 'package:pa_sreens/src/features/auth/data/remote/source/auth_source.dart';
import '../../domain/repository/auth_repository.dart';

@Injectable(as: SignupRepository)
class SignupRepositoryImpl implements SignupRepository {
  SignupRepositoryImpl(this._authSource);
  final AuthSource _authSource;

  @override
  Future<Either<Map<String, dynamic>, String>> signupCreate(
      SignupModel signupModel) async {
    try {
      Response? response = await _authSource.signupCreate(signupModel);

      if (response?.statusCode == 201) {
        return left(response?.data);
      } else {
        return right('${(response?.data['email'] ?? [
              ''
            ]).join(',')}\n${(response?.data['password'] ?? ['']).join(',')}');
      }
    } on DioException catch (e) {
      return right(handleDioError(e));
    } catch (e) {
      return right(e.toString());
    }
  }

  @override
  Future<Either<Map<String, dynamic>, String>> verifyEmail(String otp) async {
    try {
      Response? response = await _authSource.verifyEmail(otp);

      if (response?.statusCode == 200) {
        return left(response?.data);
      } else {
        print('else verify ${response?.data}');
        return right('${response?.data['message']}');
      }
    } on DioException catch (e) {
      return right(handleDioError(e));
    } catch (e) {
      print(' catch else verify -----');
      return right(e.toString());
    }
  }

  @override
  Future<Either<UserModel, String>> login(LoginModel loginModel) async {
    try {
      Response? response = await _authSource.login(loginModel);

      if (response?.statusCode == 200) {
        locator<LocalStorageService>().saveUserData(response?.data);
        return left(UserModel.fromJson(response?.data));
      } else {
        //Qamar-add1@
        log(' - - ${response?.data}');
        return right('${response?.data['message']}');
      }
    } on DioException catch (e) {
      print(' repo catch else login dio -----');
      return right(handleDioError(e));
    } catch (e) {
      print(' repo catch else login -----');
      return right(e.toString());
    }
  }

  @override
  Future<Either<Map<String, dynamic>, String>> passwordResetToken(
      String email) async {
    try {
      Response? response = await _authSource.passwordResetToken(email);

      if (response?.statusCode == 200) {
        return left(response?.data);
      } else {
        return right('${response?.data['message']}');
      }
    } on DioException catch (e) {
      return right(handleDioError(e));
    } catch (e) {
      return right(e.toString());
    }
  }

  @override
  Future<Either<Map<String, dynamic>, String>> passwordResetConfirm(
      String pass, String token) async {
    try {
      Response? response = await _authSource.passwordResetConfirm(pass, token);

      if (response?.statusCode == 200) {
        return left(response?.data);
      } else {
        return right('${response?.statusCode}\n${response?.data['message']}');
      }
    } on DioException catch (e) {
      return right(handleDioError(e));
    } catch (e) {
      return right(e.toString());
    }
  }

  @override
  Future<Either<Map<String, dynamic>, String>> passwordResetTokenValidate(
      String token) async {
    try {
      Response? response = await _authSource.passwordResetTokenValidate(token);

      if (response?.statusCode == 200) {
        return left(response?.data);
      } else {
        return right('${response?.data['message']}');
      }
    } on DioException catch (e) {
      return right(handleDioError(e));
    } catch (e) {
      return right(e.toString());
    }
  }
}
