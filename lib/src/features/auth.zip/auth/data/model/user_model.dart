import 'dart:convert';

import 'package:dio/dio.dart';

UserMessage userModelFromJson(String str) =>
    UserMessage.fromJson(json.decode(str));

String userModelToJson(UserMessage data) => json.encode(data.toJson());

class UserMessage {
  UserModel? message;

  UserMessage({
    this.message,
  });

  UserMessage copyWith({
    UserModel? message,
  }) =>
      UserMessage(
        message: message ?? this.message,
      );

  factory UserMessage.fromJson(Map<String, dynamic> json) => UserMessage(
        message: json["message"] == null
            ? null
            : UserModel.fromJson(json["message"]),
      );

  Map<String, dynamic> toJson() => {
        "message": message?.toJson(),
      };
}

class UserModel {
  String? token;
  User? user;

  UserModel({
    this.token,
    this.user,
  });

  UserModel copyWith({
    String? token,
    User? user,
  }) =>
      UserModel(
        token: token ?? this.token,
        user: user ?? this.user,
      );

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
        token: json["token"],
        user: json["user"] == null ? null : User.fromJson(json["user"]),
      );

  Map<String, dynamic> toJson() => {
        "token": token,
        "user": user?.toJson(),
      };
}

class User {
  int? id;
  String? email;
  String? fullName;
  String? location;
  int? age;
  String? phoneNo;
  String? gender;
  String? city;
  String? state;
  int? zipCode;
  bool? isCommunicationTrue;
  bool? isAgree;
  String? image;
  MultipartFile? imageUpload;

  User({
    this.id,
    this.email,
    this.fullName,
    this.location,
    this.age,
    this.phoneNo,
    this.gender,
    this.city,
    this.state,
    this.zipCode,
    this.isCommunicationTrue,
    this.isAgree,
    this.image,
    this.imageUpload,
  });

  User copyWith({
    int? id,
    String? email,
    String? fullName,
    String? location,
    int? age,
    String? phoneNo,
    String? gender,
    String? city,
    String? state,
    int? zipCode,
    bool? isCommunicationTrue,
    bool? isAgree,
    String? image,
    MultipartFile? imageUpload,
  }) =>
      User(
        id: id ?? this.id,
        email: email ?? this.email,
        fullName: fullName ?? this.fullName,
        location: location ?? this.location,
        age: age ?? this.age,
        phoneNo: phoneNo ?? this.phoneNo,
        gender: gender ?? this.gender,
        city: city ?? this.city,
        state: state ?? this.state,
        zipCode: zipCode ?? this.zipCode,
        isCommunicationTrue: isCommunicationTrue ?? this.isCommunicationTrue,
        isAgree: isAgree ?? this.isAgree,
        image: image ?? this.image,
        imageUpload: imageUpload ?? this.imageUpload,
      );

  factory User.fromJson(Map<String, dynamic> json) => User(
        id: json["id"],
        email: json["email"],
        fullName: json["full_name"],
        location: json["location"],
        age: json["age"],
        phoneNo: json["phone_no"],
        gender: json["gender"],
        city: json["city"],
        state: json["state"],
        zipCode: json["zip_code"],
        isCommunicationTrue: json["is_communication_true"],
        isAgree: json["is_agree"],
        image: json["image"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "email": email,
        "full_name": fullName,
        "location": location,
        "age": age,
        "phone_no": phoneNo,
        "gender": gender,
        "city": city,
        "state": state,
        "zip_code": zipCode,
        "is_communication_true": isCommunicationTrue,
        "is_agree": isAgree,
        "image": imageUpload,
      };
}
