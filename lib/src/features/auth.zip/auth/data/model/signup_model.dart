import 'dart:convert';

SignupModel signupModelFromJson(String str) =>
    SignupModel.fromJson(json.decode(str));

String signupModelToJson(SignupModel data) => json.encode(data.toJson());

class SignupModel {
  String? fullName;
  String? email;
  String? password;
  String? location;
  bool? isCommunicationTrue;
  bool? isAgree;

  SignupModel({
    this.fullName,
    this.email,
    this.password,
    this.location,
    this.isCommunicationTrue,
    this.isAgree,
  });

  SignupModel copyWith({
    String? fullName,
    String? email,
    String? password,
    String? location,
    bool? isCommunicationTrue,
    bool? isAgree,
  }) =>
      SignupModel(
        fullName: fullName ?? this.fullName,
        email: email ?? this.email,
        password: password ?? this.password,
        location: location ?? this.location,
        isCommunicationTrue: isCommunicationTrue ?? this.isCommunicationTrue,
        isAgree: isAgree ?? this.isAgree,
      );

  factory SignupModel.fromJson(Map<String, dynamic> json) => SignupModel(
        fullName: json["full_name"],
        email: json["email"],
        password: json["password"],
        location: json["location"],
        isCommunicationTrue: json["is_communication_true"],
        isAgree: json["is_agree"],
      );

  Map<String, dynamic> toJson() => {
        "full_name": fullName,
        "email": email,
        "password": password,
        "location": location,
        "is_communication_true": isCommunicationTrue,
        "is_agree": isAgree,
      };
}
