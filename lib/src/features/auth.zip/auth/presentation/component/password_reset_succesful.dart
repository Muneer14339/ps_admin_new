import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:pa_sreens/src/core/theme/color/app_colors_new.dart';
import 'package:pa_sreens/src/core/theme/font/app_fonts.dart';
import 'package:pa_sreens/src/core/widgets/background_paint.dart';
import 'package:pa_sreens/src/core/widgets/orange_button.dart';
import 'package:pa_sreens/src/features/auth/presentation/view/signin_view.dart';

class PasswordResetSuccessful extends StatelessWidget {
  const PasswordResetSuccessful({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
        painter: BackgroundPainter(context),
        child: Scaffold(
          // backgroundColor: Colors.transparent,
          body: Column(
            children: [
              SizedBox(width: ScreenUtil().screenWidth, height: 123.h),
              Image.asset('assets/images/PA_logo.png',
                  height: 148.h, width: 150.w),
              Container(
                margin: EdgeInsets.fromLTRB(24.w, 15.h, 24.w, 0.h),
                padding: EdgeInsets.fromLTRB(14.w, 47.h, 14.w, 0),
                decoration: BoxDecoration(
                    color: Theme.of(context).cardColor,
                    borderRadius: BorderRadius.circular(36.w)),
                child: Column(
                  children: [
                    Image.asset(
                      'assets/icons/emailverif.png',
                      height: 74.h,
                    ),
                    Padding(
                      padding: EdgeInsets.fromLTRB(0.w, 16.h, 0.w, 13.h),
                      child: Text(
                        'Successfully Reset',
                        style: TextStyle(
                            // color: AppColors.blackTextColor,
                            fontFamily: AppFontFamily.bold,
                            fontSize: 24.sp),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 16.w),
                      child: Text(
                        textAlign: TextAlign.center,
                        'Your password has been reset successfully you can proceed the log in now',
                        style: TextStyle(
                            color: AppColors.greyTextColor,
                            fontFamily: AppFontFamily.regular,
                            fontSize: 16.sp),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.fromLTRB(0, 32.h, 0, 47.h),
                      child: OrangeButton(
                        radius: 6.w,
                        text: 'Back to Sign in',
                        onTap: () => Navigator.pushAndRemoveUntil(
                            context,
                            MaterialPageRoute(
                                builder: (_) => const SigninView()),
                            (route) => false),
                        horizontalPadding: 0,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ));
  }
}
