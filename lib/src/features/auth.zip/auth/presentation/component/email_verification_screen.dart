import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:pa_sreens/src/core/theme/color/app_colors_new.dart';
import 'package:pa_sreens/src/core/theme/font/app_fonts.dart';
import 'package:pa_sreens/src/core/widgets/background_paint.dart';

import '../../../../core/widgets/orange_button.dart';
import '../view/signin_view.dart';

class EmailVerificationScreen extends StatelessWidget {
  const EmailVerificationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
        painter: BackgroundPainter(context),
        child: Scaffold(
          // backgroundColor: Colors.transparent,
          body: Column(
            children: [
              SizedBox(
                width: ScreenUtil().screenWidth,
                height: 123.h,
              ),
              Image.asset(
                'assets/images/PA_logo.png',
                height: 148.h,
                width: 150.w,
              ),
              Container(
                margin: EdgeInsets.fromLTRB(24.w, 15.h, 24.w, 0.h),
                padding: EdgeInsets.fromLTRB(14.w, 36.h, 14.w, 0),
                decoration: BoxDecoration(
                    color: Theme.of(context).cardColor,
                    borderRadius: BorderRadius.circular(36.w)),
                child: Column(
                  children: [
                    Image.asset(
                      'assets/icons/emailverif.png',
                      height: 74.h,
                    ),
                    Padding(
                      padding: EdgeInsets.fromLTRB(0.w, 16.h, 0.w, 13.h),
                      child: Text(
                        // 'Verification email sent',
                        'Email Verified',
                        style: TextStyle(
                            // color: AppColors.blackTextColor,
                            fontFamily: AppFontFamily.bold,
                            fontSize: 24.sp),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 16.w),
                      child: Text(
                        textAlign: TextAlign.center,
                        // 'We have sent you a verification email to verify your credentials. Please check your inbox or spam folder to verify your email',
                        'Your email has been successfully verified. Thank you for confirming your credentials!',
                        style: TextStyle(
                            color: AppColors.greyTextColor,
                            fontFamily: AppFontFamily.regular,
                            fontSize: 16.sp),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.fromLTRB(0, 32.h, 0, 36.h),
                      child: OrangeButton(
                        radius: 6.w,
                        text: 'Back to Sign in',
                        onTap: () => Navigator.pushAndRemoveUntil(
                            context,
                            MaterialPageRoute(
                                builder: (_) => const SigninView()),
                            (route) => false),
                        horizontalPadding: 0,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ));
  }
}
