import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:pa_sreens/src/core/services/locator/locator.dart';
import 'package:pa_sreens/src/core/theme/color/app_colors_new.dart';
import 'package:pa_sreens/src/core/theme/font/app_fonts.dart';
import 'package:pa_sreens/src/core/utils/utils.dart';
import 'package:pa_sreens/src/core/widgets/background_paint.dart';
import 'package:pa_sreens/src/core/widgets/orange_button.dart';
import 'package:pa_sreens/src/core/widgets/white_button.dart';
import 'package:pa_sreens/src/features/auth/presentation/bloc/auth_bloc.dart';
import 'package:pa_sreens/src/features/auth/presentation/component/email_verification_screen.dart';
import 'package:pa_sreens/src/features/auth/presentation/component/new_password.dart';
import 'package:pa_sreens/src/features/auth/presentation/signup_cubit.dart';
import 'package:pinput/pinput.dart';

class PasswordVerification extends StatefulWidget {
  const PasswordVerification({this.isEmailVerification, super.key});
  final bool? isEmailVerification;

  @override
  State<PasswordVerification> createState() => _PasswordVerificationState();
}

class _PasswordVerificationState extends State<PasswordVerification> {
  late final TextEditingController pinController;
  late final FocusNode focusNode;
  late final GlobalKey<FormState> formKey;
  @override
  void initState() {
    super.initState();
    formKey = GlobalKey<FormState>();
    pinController = TextEditingController();
    focusNode = FocusNode();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => TimerCubit(),
      child: CustomPaint(
        painter: BackgroundPainter(context),
        child: Scaffold(
          // backgroundColor: Colors.transparent,
          body: ListView(
            children: [
              SizedBox(
                width: ScreenUtil().screenWidth,
                height: 53.h,
              ),
              Image.asset(
                'assets/images/PA_logo.png',
                height: 99.h,
                width: 100.w,
              ),
              Container(
                margin: EdgeInsets.fromLTRB(24.w, 21.h, 24.w, 0.h),
                padding: EdgeInsets.fromLTRB(14.w, 0, 14.w, 0),
                decoration: BoxDecoration(
                    color: Theme.of(context).cardColor,
                    borderRadius: BorderRadius.circular(36.w)),
                child: Form(
                  key: formKey,
                  child: Column(
                    children: [
                      Padding(
                        padding: EdgeInsets.fromLTRB(0.w, 16.h, 0.w, 13.h),
                        child: Text(
                          'Enter Verification Code',
                          style: TextStyle(
                              // color: AppColors.blackTextColor,
                              fontFamily: AppFontFamily.bold,
                              fontSize: 24.sp),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.fromLTRB(16.w, 0, 16.w, 22.h),
                        child: Text(
                          textAlign: TextAlign.center,
                          'Please check your email inbox or a spam folder we have sent you a verification code',
                          style: TextStyle(
                              color: AppColors.greyTextColor,
                              fontFamily: AppFontFamily.regular,
                              fontSize: 16.sp),
                        ),
                      ),
                      Pinput(
                        controller: pinController,
                        focusNode: focusNode,
                        length: widget.isEmailVerification == true ? 8 : 6,
                        showCursor: true,
                        validator: (value) {
                          return null;

                          // return value == '0000'
                          //     ? null
                          //     : 'Pin is incorrect';
                        },
                        defaultPinTheme: PinTheme(
                          width: 48.w,
                          height: 48.h,
                          textStyle: TextStyle(
                              fontSize: 20.sp,
                              color: Colors.black,
                              fontFamily: AppFontFamily.regular),
                          decoration: BoxDecoration(
                            color: Colors.grey.shade300,
                            borderRadius: BorderRadius.circular(10.w),
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      BlocBuilder<TimerCubit, int>(
                        builder: (context, counter) {
                          return Text(
                            'Didn\'t get verification code? 00:${counter.toString().padLeft(2, '0')}s',
                            style: TextStyle(
                                fontSize: 14.sp,
                                color: AppColors.greyTextColor,
                                fontFamily: AppFontFamily.regular),
                          );
                        },
                      ),
                      Padding(
                        padding: EdgeInsets.fromLTRB(0, 53.h, 0, 23.h),
                        child: BlocProvider.value(
                          value: authBloc,
                          child: BlocConsumer<AuthBloc, AuthState>(
                            listener: (context, state) {
                              if (state is EmailVerifyError) {
                                toast(state.error);
                                // notification(false, state.error);
                              } else if (state is EmailVerifySuccess) {
                                Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            const EmailVerificationScreen()));
                              } else if (state is ResetPassError) {
                                toast(state.error);
                                // notification(false, state.error);
                              } else if (state is ResetPassSuccess) {
                                Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => NewPasswordScreen(
                                            token: pinController.text)));
                              }
                            },
                            builder: (context, stateEmail) {
                              if (stateEmail is EmailVerifyLoading ||
                                  stateEmail is ResetPassLoading) {
                                return const LinearProgressIndicator();
                              } else {
                                return OrangeButton(
                                  text: 'Submit',
                                  radius: 6.w,
                                  onTap: () {
                                    if (formKey.currentState!.validate()) {
                                      if (widget.isEmailVerification == true) {
                                        authBloc.add(EmailVerifyEvent(
                                            data: pinController.text));
                                      } else {
                                        authBloc.add(ResetPassValidateEvent(
                                            token: pinController.text));
                                      }
                                    } else {
                                      focusNode.unfocus();
                                    }
                                  },
                                  horizontalPadding: 0,
                                );
                              }
                            },
                          ),
                        ),
                      ),
                      WhiteButton(
                          radius: 6.w,
                          text: 'Back',
                          horizontalPadding: 0,
                          onTap: () => Navigator.pop(context)),
                      SizedBox(height: 36.h)
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  final authBloc = locator<AuthBloc>();
}
