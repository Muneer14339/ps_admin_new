import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:pa_sreens/src/core/services/locator/locator.dart';
import 'package:pa_sreens/src/core/theme/font/app_fonts.dart';
import 'package:pa_sreens/src/core/utils/utils.dart';
import 'package:pa_sreens/src/core/widgets/background_paint.dart';
import 'package:pa_sreens/src/core/widgets/orange_button.dart';
import 'package:pa_sreens/src/core/widgets/signin_textfield.dart';
import 'package:pa_sreens/src/features/auth/presentation/bloc/auth_bloc.dart';
import 'package:pa_sreens/src/features/auth/presentation/component/password_reset_succesful.dart';
import 'package:pa_sreens/src/features/auth/presentation/signup_cubit.dart';

class NewPasswordScreen extends StatefulWidget {
  const NewPasswordScreen({required this.token, super.key});
  final String token;

  @override
  State<NewPasswordScreen> createState() => _NewPasswordScreenState();
}

class _NewPasswordScreenState extends State<NewPasswordScreen> {
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();
  final _formKey = GlobalKey<FormState>();

  String? _validateConfirmPassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Confirm password is required';
    }
    if (value != _passwordController.text) {
      return 'Passwords do not match';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
        painter: BackgroundPainter(context),
        child: Scaffold(
          // backgroundColor: Colors.transparent,
          body: Form(
            key: _formKey,
            child: ListView(
              children: [
                SizedBox(width: ScreenUtil().screenWidth, height: 102.h),
                Image.asset(
                  'assets/images/PA_logo.png',
                  height: 99.h,
                  width: 100.w,
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(24.w, 44.h, 24.w, 0.h),
                  padding: EdgeInsets.fromLTRB(14.w, 0, 14.w, 0),
                  decoration: BoxDecoration(
                      color: Theme.of(context).cardColor,
                      borderRadius: BorderRadius.circular(36.w)),
                  child: BlocProvider(
                    create: (context) => NewPasswordCubit(),
                    child: BlocBuilder<NewPasswordCubit, bool>(
                      builder: (context, state) {
                        return Column(
                          children: [
                            Padding(
                              padding:
                                  EdgeInsets.fromLTRB(0.w, 34.h, 0.w, 45.h),
                              child: Text(
                                'Set New Password',
                                style: TextStyle(
                                    // color: AppColors.blackTextColor,
                                    fontFamily: AppFontFamily.bold,
                                    fontSize: 24.sp),
                              ),
                            ),
                            SigninTextfield(
                                hintText: 'Password',
                                icon: 'assets/icons/pass2.png',
                                isObscure: state,
                                visibility: context
                                    .read<NewPasswordCubit>()
                                    .togglePasswordVisibility,
                                validator: validatePasswords,
                                preIconHeight: 15.h,
                                controller: _passwordController),
                            Padding(
                              padding: EdgeInsets.fromLTRB(0, 20.h, 0, 48.h),
                              child: SigninTextfield(
                                  hintText: 'Confirm Password',
                                  isObscure: state,
                                  visibility: context
                                      .read<NewPasswordCubit>()
                                      .togglePasswordVisibility,
                                  icon: 'assets/icons/pass2.png',
                                  preIconHeight: 15.h,
                                  validator: _validateConfirmPassword,
                                  controller: _confirmPasswordController),
                            ),
                            BlocProvider.value(
                              value: authBloc,
                              child: BlocConsumer<AuthBloc, AuthState>(
                                listener: (context, state) {
                                  if (state is ResetPassError) {
                                    toast(state.error);
                                    // notification(false, state.error);
                                  } else if (state is ResetPassSuccess) {
                                    Navigator.pushReplacement(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                const PasswordResetSuccessful()));
                                  }
                                },
                                builder: (context, state) {
                                  if (state is ResetPassLoading) {
                                    return const LinearProgressIndicator();
                                  }
                                  return OrangeButton(
                                    radius: 6.w,
                                    text: 'Submit',
                                    onTap: () {
                                      if (_formKey.currentState!.validate()) {
                                        authBloc.add(ResetPassConfirmEvent(
                                            pass: _passwordController.text,
                                            token: widget.token));
                                      }
                                    },
                                    horizontalPadding: 0,
                                  );
                                },
                              ),
                            ),
                            SizedBox(
                              height: 59.h,
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
        ));
  }

  final authBloc = locator<AuthBloc>();
}
