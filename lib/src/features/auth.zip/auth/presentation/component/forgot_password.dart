import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:pa_sreens/src/core/services/locator/locator.dart';
import 'package:pa_sreens/src/core/theme/color/app_colors_new.dart';
import 'package:pa_sreens/src/core/theme/font/app_fonts.dart';
import 'package:pa_sreens/src/core/utils/utils.dart';
import 'package:pa_sreens/src/core/widgets/background_paint.dart';
import 'package:pa_sreens/src/core/widgets/orange_button.dart';
import 'package:pa_sreens/src/core/widgets/signin_textfield.dart';
import 'package:pa_sreens/src/core/widgets/white_button.dart';
import 'package:pa_sreens/src/features/auth/presentation/bloc/auth_bloc.dart';
import 'package:pa_sreens/src/features/auth/presentation/component/password_code.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  TextEditingController emailController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  String? _validateEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'Email is required';
    }
    // Basic email format check
    final emailRegex = RegExp(r'^[^@]+@[^@]+\.[^@]+');
    if (!emailRegex.hasMatch(value)) {
      return 'Enter a valid email';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
        painter: BackgroundPainter(context),
        child: Scaffold(
          // backgroundColor: Colors.transparent,
          body: Form(
            key: _formKey,
            child: ListView(
              children: [
                SizedBox(
                  width: ScreenUtil().screenWidth,
                  height: 53.h,
                ),
                Image.asset(
                  'assets/images/PA_logo.png',
                  width: 100.w,
                  height: 99.h,
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(24.w, 44.h, 24.w, 0.h),
                  padding: EdgeInsets.fromLTRB(14.w, 0, 14.w, 0),
                  decoration: BoxDecoration(
                      color: Theme.of(context).cardColor,
                      borderRadius: BorderRadius.circular(36.w)),
                  child: Column(
                    children: [
                      Padding(
                        padding: EdgeInsets.fromLTRB(0.w, 16.h, 0.w, 13.h),
                        child: Text(
                          'Forgot Password',
                          style: TextStyle(
                              // color: AppColors.blackTextColor,
                              fontFamily: AppFontFamily.bold,
                              fontSize: 24.sp),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 16.w),
                        child: Text(
                          textAlign: TextAlign.center,
                          'Enter your username or email address and we will send you a link to reset your password.',
                          style: TextStyle(
                              color: AppColors.greyTextColor,
                              fontFamily: AppFontFamily.regular,
                              fontSize: 16.sp),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.fromLTRB(0, 22.h, 0, 53.h),
                        child: SigninTextfield(
                            hintText: 'Email',
                            validator: _validateEmail,
                            icon: 'assets/icons/email.png',
                            preIconHeight: 15.h,
                            controller: emailController),
                      ),
                      BlocProvider.value(
                        value: authBloc,
                        child: BlocConsumer<AuthBloc, AuthState>(
                          listener: (context, state) {
                            if (state is ResetPassError) {
                              toast(state.error);
                              // notification(false, state.error);
                            } else if (state is ResetPassSuccess) {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          const PasswordVerification()));
                            }
                          },
                          builder: (context, state) {
                            if (state is ResetPassLoading) {
                              return const LinearProgressIndicator();
                            }
                            return OrangeButton(
                              text: 'Submit',
                              radius: 6.w,
                              onTap: () {
                                if (_formKey.currentState!.validate()) {
                                  authBloc.add(ResetPassEvent(
                                      email: emailController.text));
                                }
                              },
                              horizontalPadding: 0,
                            );
                          },
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.fromLTRB(0, 23.h, 0, 36.h),
                        child: WhiteButton(
                            text: 'Back',
                            radius: 6.w,
                            horizontalPadding: 0,
                            onTap: () => Navigator.pop(context)),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ));
  }

  final authBloc = locator<AuthBloc>();
}
