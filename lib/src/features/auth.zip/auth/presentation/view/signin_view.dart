import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:pa_sreens/src/core/services/sqflite_service/db_file_loading_service.dart';
import 'package:pa_sreens/src/core/theme/color/app_colors_new.dart';
import 'package:pa_sreens/src/core/theme/font/app_fonts.dart';
import 'package:pa_sreens/src/core/widgets/background_paint.dart';
import 'package:pa_sreens/src/core/widgets/orange_button.dart';
import 'package:pa_sreens/src/core/widgets/signin_textfield.dart';
import 'package:pa_sreens/src/features/auth/data/model/login_model.dart';
import 'package:pa_sreens/src/features/auth/presentation/bloc/auth_bloc.dart';
import 'package:pa_sreens/src/features/bottom_nev/presntation/bloc/tab_bloc.dart';
import 'package:pa_sreens/src/features/bottom_nev/presntation/view/tabs_view.dart';
import 'package:pa_sreens/src/features/auth/presentation/component/forgot_password.dart';
import 'package:pa_sreens/src/features/auth/presentation/view/signup_view.dart';
import 'package:pa_sreens/src/features/train/stage/presentation/stage_cubit/satge_cubit.dart';
import '../../../../core/utils/utils.dart';

class SigninView extends StatefulWidget {
  const SigninView({super.key});

  @override
  State<SigninView> createState() => _SigninViewState();
}

class _SigninViewState extends State<SigninView> {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool isAutoValidate = false;
  String? _validateEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'Email is required';
    }
    // Basic email format check
    final emailRegex = RegExp(r'^[^@]+@[^@]+\.[^@]+');
    if (!emailRegex.hasMatch(value)) {
      return 'Enter a valid email';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
        painter: BackgroundPainter(context),
        child: BlocProvider(
          create: (context) => AutoValidationCubit(),
          child: BlocBuilder<AutoValidationCubit, bool>(
            builder: (context, state) {
              isAutoValidate = state;
              return Scaffold(
                // backgroundColor: Colors.transparent,
                body: Form(
                  autovalidateMode: state
                      ? AutovalidateMode.always
                      : AutovalidateMode.disabled,
                  key: _formKey,
                  child: ListView(
                    children: [
                      SizedBox(width: ScreenUtil().screenWidth, height: 53.h),
                      Image.asset('assets/images/PA_logo.png',
                          width: 100.w, height: 100.h),
                      Container(
                          margin: EdgeInsets.fromLTRB(24.w, 15.h, 24.w, 0.h),
                          padding: EdgeInsets.fromLTRB(14.w, 0, 14.w, 0),
                          decoration: BoxDecoration(
                              color: Theme.of(context).cardColor,
                              borderRadius: BorderRadius.circular(36.w)),
                          child: Column(
                            children: [
                              Padding(
                                padding:
                                    EdgeInsets.fromLTRB(0.w, 34.h, 0.w, 32.h),
                                child: Text(
                                  'Sign in to your account',
                                  style: TextStyle(
                                      // color: AppColors.black,
                                      fontFamily: AppFontFamily.regular,
                                      fontSize: 24.sp),
                                ),
                              ),
                              SigninTextfield(
                                  hintText: 'Email',
                                  validator: _validateEmail,
                                  icon: 'assets/icons/email.png',
                                  preIconHeight: 15.h,
                                  controller: emailController),
                              SizedBox(height: 24.h),
                              SigninTextfield(
                                  hintText: 'Password',
                                  validator: validateLoginPass,
                                  icon: 'assets/icons/pass2.png',
                                  preIconHeight: 18.h,
                                  controller: passwordController),
                              Padding(
                                  padding:
                                      EdgeInsets.fromLTRB(0, 18.h, 0, 34.h),
                                  child: Align(
                                      alignment: Alignment.topRight,
                                      child: InkWell(
                                          onTap: () => Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      const ForgotPasswordScreen())),
                                          child: Text('Forgot Password?',
                                              style: TextStyle(
                                                  color:
                                                      AppColors.kPrimaryColor,
                                                  fontFamily:
                                                      AppFontFamily.regular,
                                                  fontSize: 16.sp))))),
                              BlocConsumer<AuthBloc, AuthState>(
                                listener: (context, state) async {
                                  if (state is LoginError) {
                                    toast(state.error);
                                  } else if (state is LoginSuccess) {
                                    BotToast.showLoading();
                                    await DbFileLoadingService()
                                        .openDatabaseFromAssets();
                                    BotToast.closeAllLoading();
                                    if (context.mounted) {
                                      //I set this because Tabbloc is not disposed and when we logout from profile page, then by logging in we the selected tab still is profile view with LOGGED ot profile data
                                      context
                                          .read<TabBloc>()
                                          .add(const TabEvent.setTab(0));
                                      Navigator.pushAndRemoveUntil(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) =>
                                                  const AppTabsView()),
                                          (route) => false);
                                    }
                                  }
                                },
                                builder: (context, statelogin) {
                                  if (statelogin is LoginLoading) {
                                    return const LinearProgressIndicator();
                                  } else {
                                    return OrangeButton(
                                      text: 'Sign in',
                                      onTap: () async {
                                        if (_formKey.currentState!.validate()) {
                                          context.read<AuthBloc>().add(
                                              LoginEvent(
                                                  data: LoginModel(
                                                      email:
                                                          emailController.text,
                                                      password:
                                                          passwordController
                                                              .text)));
                                        } else {
                                          !isAutoValidate
                                              ? context
                                                  .read<AutoValidationCubit>()
                                                  .enableAuto()
                                              : '';
                                        }
                                      },
                                      horizontalPadding: 0,
                                    );
                                  }
                                },
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: [
                                  SizedBox(
                                      width: 129.w,
                                      child: const Divider(height: 1)),
                                  Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          4.w, 34.h, 4.w, 34.h),
                                      child: Text(
                                        'or',
                                        style: TextStyle(
                                            color: AppColors.greyTextColor,
                                            fontFamily: AppFontFamily.regular,
                                            fontSize: 16.sp),
                                      )),
                                  SizedBox(
                                      width: 129.w,
                                      child: const Divider(height: 1))
                                ],
                              ),
                              Padding(
                                padding:
                                    EdgeInsets.fromLTRB(63.w, 0, 63.w, 34.h),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Image.asset(
                                      'assets/icons/fb.png',
                                      height: 30.h,
                                      width: 30.w,
                                    ),
                                    Image.asset(
                                      'assets/icons/google.png',
                                      height: 30.h,
                                      width: 31.w,
                                    ),
                                    Image.asset(
                                      'assets/icons/apple.png',
                                      height: 30.h,
                                      width: 31.w,
                                      color: Theme.of(context).iconTheme.color,
                                    )
                                  ],
                                ),
                              )
                            ],
                          )),
                      Center(
                        child: Padding(
                          padding: EdgeInsets.fromLTRB(24.w, 20.h, 24.w, 10.h),
                          child: RichText(
                            text: TextSpan(
                                text: 'Dont have an account? ',
                                style: TextStyle(
                                    color: Theme.of(context).iconTheme.color,
                                    fontFamily: AppFontFamily.regular,
                                    fontSize: 16.sp),
                                children: [
                                  TextSpan(
                                    recognizer: TapGestureRecognizer()
                                      ..onTap = () {
                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    const SignupView()));
                                      },
                                    text: 'Sign up',
                                    style: TextStyle(
                                        color: AppColors.kPrimaryColor,
                                        fontFamily: AppFontFamily.regular,
                                        fontSize: 16.sp),
                                  )
                                ]),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ));
  }

  // final authBloc = locator<AuthBloc>();
}
