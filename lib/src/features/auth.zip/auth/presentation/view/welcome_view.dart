import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:pa_sreens/src/core/theme/font/app_fonts.dart';
import 'package:pa_sreens/src/core/widgets/border_button.dart';
import 'package:pa_sreens/src/core/widgets/primary_button.dart';
import 'package:pa_sreens/src/core/widgets/text_bullets.dart';
import 'package:pa_sreens/src/core/utils/utils.dart';
import 'package:pa_sreens/src/features/auth/presentation/view/signup_view.dart';

class WelcomeView extends StatelessWidget {
  const WelcomeView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).cardColor,
      body: ListView(
        padding: EdgeInsets.zero,
        children: [
          SizedBox(
              width: ScreenUtil().screenWidth,
              height: 320.h,
              child: Image.asset(
                'assets/images/signup.png',
                fit: BoxFit.cover,
              )),
          Padding(
            padding: EdgeInsets.fromLTRB(24.w, 20.h, 24.w, 12.h),
            child: Text(
              'With a MyPulseAim account, you can',
              style: TextStyle(
                  // color: Colors.amber,
                  fontSize: 20.sp,
                  fontFamily: AppFontFamily.bold),
            ),
          ),
          BulletPointText(
            text: "Save session data.",
            padding: 24.w,
          ),
          BulletPointText(
            text: "Monitor your performance and track progress.",
            padding: 24.w,
          ),
          BulletPointText(
            text: "Compare your performance with regional or global averages.",
            padding: 24.w,
          ),
          BulletPointText(
            text: "Join the PulseAim training community.",
            padding: 24.w,
          ),
          BulletPointText(
            text: "Accesss exclusive discounts and special offers.",
            padding: 24.w,
          ),
          BulletPointText(
            text:
                "Stay updated on upcoming events, workshops, and competitions.",
            padding: 24.w,
          ),
          SizedBox(
            height: 12.h,
          ),
          // OrangeButton(
          //     text: 'Sign in',
          //     onTap: () => Navigator.pushNamed(context, '/signIN')),
          PrimaryButton(
              margin: hPadding,
              title: 'Sign in',
              onTap: () => Navigator.pushNamed(context, '/signIN')),
          SizedBox(height: 16.h),
          BorderButton(
              title: 'Sign up',
              margin: hPadding,
              color: Theme.of(context).iconTheme.color,
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const SignupView()))),
          const Gap(8),
          // WhiteButton(
          //     text: 'Sign up',
          //     onTap: () => Navigator.push(
          //         context,
          //         MaterialPageRoute(
          //             builder: (context) => const SignupScreen())))
        ],
      ),
    );
  }
}
