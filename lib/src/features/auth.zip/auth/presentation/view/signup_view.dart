import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:pa_sreens/src/core/services/locator/locator.dart';
import 'package:pa_sreens/src/core/theme/color/app_colors_new.dart';
import 'package:pa_sreens/src/core/theme/font/app_fonts.dart';
import 'package:pa_sreens/src/core/utils/utils.dart';
import 'package:pa_sreens/src/core/widgets/background_paint.dart';
import 'package:pa_sreens/src/core/widgets/custom_csc_picker.dart';
import 'package:pa_sreens/src/core/widgets/orange_button.dart';
import 'package:pa_sreens/src/core/widgets/signin_textfield.dart';
import 'package:pa_sreens/src/features/auth/data/model/signup_model.dart';
import 'package:pa_sreens/src/features/auth/domain/signup_entity.dart';
import 'package:pa_sreens/src/features/auth/presentation/bloc/auth_bloc.dart';
import 'package:pa_sreens/src/features/auth/presentation/signup_cubit.dart';
import 'package:pa_sreens/src/features/train/stage/presentation/stage_cubit/satge_cubit.dart';
import '../component/password_code.dart';

class SignupView extends StatefulWidget {
  const SignupView({super.key});

  @override
  State<SignupView> createState() => _SignupViewState();
}

class _SignupViewState extends State<SignupView> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();
  final TextEditingController _locationController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool isAutoValidate = false;

  // Validators
  String? _validateFullName(String? value) {
    if (value == null || value.isEmpty) {
      return 'Full name is required';
    }
    return null;
  }

  String? _validateLocation(String? value) {
    if (value == null || value.isEmpty) {
      return 'Location is required';
    }
    return null;
  }

  String? _validateEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'Email is required';
    }
    final emailRegex = RegExp(r'^[^@]+@[^@]+\.[^@]+');
    if (!emailRegex.hasMatch(value)) {
      return 'Enter a valid email';
    }
    return null;
  }

  String? _validateConfirmPassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Confirm password is required';
    }
    if (value != _passwordController.text) {
      return 'Passwords do not match';
    }
    return null;
  }

  final blocSign = locator<AuthBloc>();
  final cubit = SignupCubit();

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => cubit,
      child: BlocProvider(
        create: (context) => AutoValidationCubit(),
        child: CustomPaint(
            painter: BackgroundPainter(context),
            child: BlocBuilder<AutoValidationCubit, bool>(
              builder: (context, state) {
                isAutoValidate = state;
                return Scaffold(
                  // backgroundColor: Colors.transparent,
                  body: Form(
                    autovalidateMode: state
                        ? AutovalidateMode.always
                        : AutovalidateMode.disabled,
                    key: _formKey,
                    child: BlocBuilder<SignupCubit, SignupEntity>(
                      builder: (context, state) {
                        return BlocProvider.value(
                          value: blocSign,
                          child: BlocConsumer<AuthBloc, AuthState>(
                            listener: (context, state) {
                              if (state is SignupError) {
                                toast(state.error);
                              } else if (state is SignupSuccess) {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            const PasswordVerification(
                                                isEmailVerification: true)));
                              }
                            },
                            builder: (context, createState) {
                              return ListView(
                                children: [
                                  SizedBox(
                                      width: ScreenUtil().screenWidth,
                                      height: 32.h),
                                  SizedBox(
                                      height: 70.h,
                                      child: Image.asset(
                                          'assets/images/PA_logo.png',
                                          fit: BoxFit.contain)),
                                  Padding(
                                    padding: EdgeInsets.fromLTRB(
                                        24.w, 15.h, 24.w, 0.h),
                                    child: Container(
                                      padding:
                                          EdgeInsets.fromLTRB(14.w, 0, 14.w, 0),
                                      decoration: BoxDecoration(
                                          color: Theme.of(context)
                                              .cardColor, //AppColors.white,
                                          borderRadius:
                                              BorderRadius.circular(36.w)),
                                      child: Column(
                                        children: [
                                          Padding(
                                            padding: EdgeInsets.fromLTRB(
                                                0.w, 20.h, 0.w, 20.h),
                                            child: Text(
                                              'Create a new account',
                                              style: TextStyle(
                                                  // color: AppColors.black,
                                                  fontFamily:
                                                      AppFontFamily.regular,
                                                  fontSize: 24.sp),
                                            ),
                                          ),
                                          SigninTextfield(
                                              hintText: 'Full Name',
                                              validator: _validateFullName,
                                              icon:
                                                  'assets/icons/user_icon.png',
                                              preIconHeight: 20.h,
                                              controller: _nameController),
                                          SizedBox(height: 20.h),
                                          SigninTextfield(
                                              hintText: 'Email',
                                              validator: _validateEmail,
                                              icon: 'assets/icons/email.png',
                                              preIconHeight: 15.h,
                                              controller: _emailController),
                                          SizedBox(height: 20.h),
                                          SigninTextfield(
                                              hintText: 'Password',
                                              validator: validatePasswords,
                                              isObscure: state.obscurePassword,
                                              visibility: cubit
                                                  .togglePasswordVisibility,
                                              preIconHeight: 18.h,
                                              icon: 'assets/icons/pass2.png',
                                              controller: _passwordController),
                                          SizedBox(height: 20.h),
                                          SigninTextfield(
                                              hintText: 'Confirm Password',
                                              validator:
                                                  _validateConfirmPassword,
                                              isObscure: state.obscurePassword,
                                              visibility: cubit
                                                  .togglePasswordVisibility,
                                              icon: 'assets/icons/pass2.png',
                                              preIconHeight: 18.h,
                                              controller:
                                                  _confirmPasswordController),
                                          SizedBox(height: 20.h),
                                          CSCPickerCustom(
                                            isSignUpScreen: true,
                                            countryDropdownLabel: 'Location',
                                            flagState: CountryFlag.DISABLE,
                                            selectedItemStyle: TextStyle(
                                                fontSize: 14.sp,
                                                // color: AppColors.greyTextColor,
                                                fontFamily:
                                                    AppFontFamily.regular),
                                            showCities: false,
                                            showStates: false,
                                            onCountryChanged: (value) {
                                              _locationController.text = value;
                                            },
                                            onStateChanged: (value) {},
                                            onCityChanged: (value) {},
                                            dropdownDecoration: BoxDecoration(
                                              color: Theme.of(context)
                                                  .inputDecorationTheme
                                                  .fillColor,
                                              borderRadius: BorderRadius.all(
                                                Radius.circular(8.w),
                                              ),
                                            ),
                                          ),
                                          SizedBox(height: 20.h),
                                          Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              InkWell(
                                                onTap:
                                                    cubit.toggleAgreeToRecieve,
                                                child: Icon(
                                                  color: state.agreeToRecieve
                                                      ? AppColors.kPrimaryColor
                                                      : Theme.of(context)
                                                          .iconTheme
                                                          .color,
                                                  Icons
                                                      .check_circle_outline_rounded,
                                                  size: 19.w,
                                                ),
                                              ),
                                              SizedBox(
                                                width: 10.w,
                                              ),
                                              Flexible(
                                                child: Text(
                                                  'Yes, I’d like to receive PulseAim emails & communications to hear about new products, promotions, and more.',
                                                  style: TextStyle(
                                                      // color: AppColors
                                                      //     .blackTextColor,
                                                      fontFamily:
                                                          AppFontFamily.regular,
                                                      fontSize: 14.sp),
                                                ),
                                              )
                                            ],
                                          ),
                                          SizedBox(height: 5.h),
                                          Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              InkWell(
                                                onTap: cubit.toggleAgreeToTerms,
                                                child: Icon(
                                                  color: state.agreeToTerms
                                                      ? AppColors.kPrimaryColor
                                                      : Theme.of(context)
                                                          .iconTheme
                                                          .color,
                                                  Icons
                                                      .check_circle_outline_rounded,
                                                  size: 19.w,
                                                ),
                                              ),
                                              SizedBox(width: 10.w),
                                              Flexible(
                                                child: RichText(
                                                  text: TextSpan(
                                                      text: 'I agree with ',
                                                      style: TextStyle(
                                                          // color: AppColors
                                                          //     .blackTextColor,
                                                          fontFamily:
                                                              AppFontFamily
                                                                  .regular,
                                                          fontSize: 14.sp),
                                                      children: [
                                                        TextSpan(
                                                          text:
                                                              'Terms & Conditions & Privacy Policy',
                                                          style: TextStyle(
                                                              color: AppColors
                                                                  .kPrimaryColor,
                                                              fontFamily:
                                                                  AppFontFamily
                                                                      .regular,
                                                              fontSize: 14.sp),
                                                        )
                                                      ]),
                                                ),
                                              ),
                                            ],
                                          ),
                                          SizedBox(height: 20.h),
                                          createState is SignupLoading
                                              ? const LinearProgressIndicator()
                                              : OrangeButton(
                                                  radius: 6.w,
                                                  text: 'Sign up',
                                                  onTap: () {
                                                    if (_formKey.currentState!
                                                        .validate()) {
                                                      blocSign.add(SignupCreateEvent(
                                                          data: SignupModel(
                                                              email:
                                                                  _emailController
                                                                      .text,
                                                              fullName:
                                                                  _nameController
                                                                      .text,
                                                              isAgree: state
                                                                  .agreeToTerms,
                                                              location:
                                                                  _locationController
                                                                      .text,
                                                              isCommunicationTrue:
                                                                  state
                                                                      .agreeToRecieve,
                                                              password:
                                                                  _passwordController
                                                                      .text)));
                                                    } else {
                                                      !isAutoValidate
                                                          ? context
                                                              .read<
                                                                  AutoValidationCubit>()
                                                              .enableAuto()
                                                          : '';
                                                    }
                                                  },
                                                  horizontalPadding: 0,
                                                ),
                                          SizedBox(height: 25.h),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Center(
                                    child: Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          24.w, 20.h, 24.w, 20.h),
                                      child: RichText(
                                        text: TextSpan(
                                            text: 'Already have an account? ',
                                            style: TextStyle(
                                                color: Theme.of(context)
                                                    .iconTheme
                                                    .color,
                                                fontFamily:
                                                    AppFontFamily.regular,
                                                fontSize: 16.sp),
                                            children: [
                                              TextSpan(
                                                text: 'Sign in',
                                                recognizer:
                                                    TapGestureRecognizer()
                                                      ..onTap = () {
                                                        Navigator.pushNamed(
                                                            context, '/signIN');
                                                      },
                                                style: TextStyle(
                                                    color:
                                                        AppColors.kPrimaryColor,
                                                    fontFamily:
                                                        AppFontFamily.regular,
                                                    fontSize: 16.sp),
                                              )
                                            ]),
                                      ),
                                    ),
                                  ),
                                ],
                              );
                            },
                          ),
                        );
                      },
                    ),
                  ),
                );
              },
            )),
      ),
    );
  }
}
