part of 'auth_bloc.dart';

@immutable
sealed class AuthEvent {}

final class SignupCreateEvent extends AuthEvent {
  final SignupModel data;
  SignupCreateEvent({required this.data});
}

final class EmailVerifyEvent extends AuthEvent {
  final String data;
  EmailVerifyEvent({required this.data});
}

final class LoginEvent extends AuthEvent {
  final LoginModel data;
  LoginEvent({required this.data});
}

final class ResetPassEvent extends AuthEvent {
  final String email;
  ResetPassEvent({required this.email});
}

final class ResetPassValidateEvent extends AuthEvent {
  final String token;
  ResetPassValidateEvent({required this.token});
}

final class ResetPassConfirmEvent extends AuthEvent {
  final String pass;
  final String token;
  ResetPassConfirmEvent({required this.pass, required this.token});
}
