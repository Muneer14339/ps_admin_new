import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:injectable/injectable.dart';
import 'package:pa_sreens/src/features/auth/data/model/login_model.dart';
import 'package:pa_sreens/src/features/auth/data/model/signup_model.dart';
import 'package:pa_sreens/src/features/auth/domain/usecase/auth_usecase.dart';

import '../../data/model/user_model.dart';

part 'auth_event.dart';
part 'auth_state.dart';

@injectable
class AuthBloc extends Bloc<AuthEvent, AuthState> {
  final SignupUsecase usecase;
  AuthBloc(this.usecase) : super(AuthInitial()) {
    on<AuthEvent>((event, emit) {});
    //
    on<SignupCreateEvent>((event, emit) => createSignup(emit, event.data));
    //
    on<EmailVerifyEvent>((event, emit) => verifyEmail(emit, event.data));
    //
    on<LoginEvent>((event, emit) => login(emit, event.data));

    //
    on<ResetPassEvent>((event, emit) => passwordResetToken(emit, event.email));

    //
    on<ResetPassValidateEvent>(
        (event, emit) => passwordResetTokenValidate(emit, event.token));

    //
    on<ResetPassConfirmEvent>(
        (event, emit) => passwordResetConfirm(emit, event.pass, event.token));
  }

  //----------------------------------------------------- Methods

  Future<void> createSignup(
      Emitter<AuthState> emit, SignupModel signupModel) async {
    emit(SignupLoading());
    await usecase.createSignup(signupModel).then((v) {
      v.fold(
        (l) => emit(SignupSuccess(l)),
        (r) => emit(SignupError(r)),
      );
    });
  }

  //

  Future<void> verifyEmail(Emitter<AuthState> emit, String otp) async {
    emit(EmailVerifyLoading());
    await usecase.verifyEmail(otp).then((v) {
      v.fold(
        (l) => emit(EmailVerifySuccess(l)),
        (r) => emit(EmailVerifyError(r)),
      );
    });
  }

  //

  Future<void> login(Emitter<AuthState> emit, LoginModel loginModel) async {
    emit(LoginLoading());
    await usecase.login(loginModel).then((v) {
      v.fold(
        (l) => emit(LoginSuccess(l)),
        (r) => emit(LoginError(r)),
      );
    });
  }

  //

  Future<void> passwordResetToken(Emitter<AuthState> emit, String email) async {
    emit(ResetPassLoading());
    await usecase.passwordResetToken(email).then((v) {
      v.fold(
        (l) => emit(ResetPassSuccess(l)),
        (r) => emit(ResetPassError(r)),
      );
    });
  }

  //

  Future<void> passwordResetTokenValidate(
      Emitter<AuthState> emit, String token) async {
    emit(ResetPassLoading());
    await usecase.passwordResetTokenValidate(token).then((v) {
      v.fold(
        (l) => emit(ResetPassSuccess(l)),
        (r) => emit(ResetPassError(r)),
      );
    });
  }

  //

  Future<void> passwordResetConfirm(
      Emitter<AuthState> emit, String pass, String token) async {
    emit(ResetPassLoading());
    await usecase.passwordResetConfirm(pass, token).then((v) {
      v.fold(
        (l) => emit(ResetPassSuccess(l)),
        (r) => emit(ResetPassError(r)),
      );
    });
  }
}
