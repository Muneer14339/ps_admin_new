part of 'auth_bloc.dart';

sealed class AuthState {}

final class AuthInitial extends AuthState {}

//----------------------------------------------------- createSignup
final class SignupLoading extends AuthState {}

final class SignupSuccess extends AuthState {
  final Map<String, dynamic> response;
  SignupSuccess(this.response);
}

final class SignupError extends AuthState {
  final String error;
  SignupError(this.error);
}

//----------------------------------------------------- verifyEmail

final class EmailVerifyLoading extends AuthState {}

final class EmailVerifySuccess extends AuthState {
  final Map<String, dynamic> response;
  EmailVerifySuccess(this.response);
}

final class EmailVerifyError extends AuthState {
  final String error;
  EmailVerifyError(this.error);
}

//----------------------------------------------------- verifyEmail

final class LoginLoading extends AuthState {}

final class LoginSuccess extends AuthState {
  final UserModel response;
  LoginSuccess(this.response);
}

final class LoginError extends AuthState {
  final String error;
  LoginError(this.error);
}

//----------------------------------------------------- passwordReset

final class ResetPassLoading extends AuthState {}

final class ResetPassSuccess extends AuthState {
  final Map<String, dynamic> response;
  ResetPassSuccess(this.response);
}

final class ResetPassError extends AuthState {
  final String error;
  ResetPassError(this.error);
}
